package com.alpha;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BookCar {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int custmerid;
	private String custname;
	private long phone;
	private String fromdate;
	private String todate;
	private int carid;
	public int getCustmerid() {
		return custmerid;
	}
	public void setCustmerid(int custmerid) {
		this.custmerid = custmerid;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public String getFromdate() {
		return fromdate;
	}
	public void setFromdate(String fromdate) {
		this.fromdate = fromdate;
	}
	public String getTodate() {
		return todate;
	}
	public void setTodate(String todate) {
		this.todate = todate;
	}
	public int getCarid() {
		return carid;
	}
	public void setCarid(int carid) {
		this.carid = carid;
	}
	public BookCar(String custname, long phone, String fromdate, String todate, int carid) {
		super();
		this.custname = custname;
		this.phone = phone;
		this.fromdate = fromdate;
		this.todate = todate;
		this.carid = carid;
	}
	public BookCar() {
		super();
	}
	
	
	
	

	
	

}
