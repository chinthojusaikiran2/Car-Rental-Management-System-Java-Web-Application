package com.alpha;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/completebooking")
public class Completebooking extends HttpServlet {

    private static final long serialVersionUID = 1L;

    EntityManagerFactory emf = Persistence.createEntityManagerFactory("application");

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        int carid = Integer.parseInt(req.getParameter("carid"));
        int custmerid = Integer.parseInt(req.getParameter("custmerid"));

        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();

            Booking b = em.find(Booking.class, custmerid);
            if (b != null) {
                em.remove(b);
            }

            Car c = em.find(Car.class, carid);
            if (c != null) {
                c.setStatus("Available");
                em.merge(c);
            }

            et.commit();

            resp.sendRedirect("success.jsp");

        } catch (Exception e) {
            et.rollback();
            e.printStackTrace();
            resp.sendRedirect("error.jsp");

        } finally {
            em.close();
        }
    }
}
