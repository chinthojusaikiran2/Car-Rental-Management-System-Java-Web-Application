package com.alpha;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/seeallbooking")
public class SeeAllBooking extends HttpServlet {

    private static final long serialVersionUID = 1L;

    // Create once
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("application");

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        EntityManager em = emf.createEntityManager();

        try {
            String query = "SELECT b FROM BookCar b";
            List<BookCar> bookcar = em.createQuery(query, BookCar.class).getResultList();

            req.setAttribute("carlist", bookcar);

            RequestDispatcher rd = req.getRequestDispatcher("displayAllBookedCar.jsp");
            rd.forward(req, resp);

        } finally {
            em.close();
        }
    }
}
