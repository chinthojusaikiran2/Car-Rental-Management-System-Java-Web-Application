package com.alpha;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BookCar")
public class Booking  extends HttpServlet{
	 @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 EntityManagerFactory emf=Persistence.createEntityManagerFactory("application");
			EntityManager em=emf.createEntityManager();
			EntityTransaction et=em.getTransaction();
			
			
			int custmerid=Integer.parseInt(req.getParameter("custmerid"));
			String custname=req.getParameter("custname");
			long phone=Long.parseLong(req.getParameter("phone"));
			String fromdate=req.getParameter("fromdate");
			String todate=req.getParameter("todate");
			int carid=Integer.parseInt(req.getParameter("carid"));
			BookCar bookcar=new BookCar(custname, phone, fromdate, todate, carid);
			et.begin();
			Car c=em.find(Car.class, carid);
			c.setStatus("booked");

			em.merge(c);
			em.persist(bookcar);
			
			et.commit();

			
		
	}
	

}
