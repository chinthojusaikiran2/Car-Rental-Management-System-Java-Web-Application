<%@page import="com.alpha.Car"%>
<%@page import="java.util.List"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Car Details</title>

<!-- Bootstrap -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

<style>
    :root{
        --page-bg: linear-gradient(135deg, #1e3c72, #2a5298);
        --text-color: #ffffff;
        --card-text: #ffffff;
        --btn-text: #111827;
        --btn-bg-light: rgba(255,255,255,0.9);
        --btn-bg-dark: rgba(0,0,0,0.12);
        --card-shadow: 0px 10px 20px rgba(0,0,0,0.25);
    }

    body {
        background: var(--page-bg);
        min-height: 100vh;
        padding: 40px;
        font-family: 'Poppins', sans-serif;
        color: var(--text-color);
        transition: background 300ms ease, color 300ms ease;
    }

    body.dark-mode {
        --page-bg: linear-gradient(120deg, #0f1724, #0b1220);
        --text-color: #e6eef8;
        --card-text: #f1f5f9;
        --btn-text: #e6eef8;
        --btn-bg-light: rgba(255,255,255,0.06);
        --btn-bg-dark: rgba(255,255,255,0.08);
        --card-shadow: 0px 10px 24px rgba(0,0,0,0.5);
    }

    .topbar {
        display:flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 18px;
    }

    .car-card {
        border-radius: 18px;
        padding: 18px;
        color: var(--card-text);
        box-shadow: var(--card-shadow);
        transition: all 0.35s ease;
        transform: translateY(0px);
    }

    .car-card:hover {
        transform: translateY(-10px);
        filter: brightness(1.04);
        box-shadow: 0px 14px 26px rgba(0,0,0,0.22);
    }

    .car-img {
        width: 100%;
        height: 180px;
        object-fit: cover;
        border-radius: 12px;
        margin-bottom: 12px;
    }

    .car-title {
        font-size: 1.35rem;
        font-weight: 700;
        color: inherit;
    }

    .car-info {
        font-size: 0.98rem;
        margin: 6px 0;
        opacity: 0.95;
        color: inherit;
    }

    .action-btn {
        margin-right: 8px;
        border-radius: 25px;
        padding: 6px 14px;
        font-size: 0.9rem;
    }

    .toggle-switch {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        font-weight: 600;
        color: var(--text-color);
    }

    .theme-switch {
        width:50px;
        height:28px;
        background: rgba(255,255,255,0.18);
        border-radius: 999px;
        position: relative;
        cursor: pointer;
        transition: all 200ms ease;
    }
    .theme-switch .knob {
        position: absolute;
        top:3px;
        left:3px;
        width:22px;
        height:22px;
        background:white;
        border-radius:50%;
        transition: all 200ms ease;
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }
    body.dark-mode .theme-switch{
        background: rgba(255,255,255,0.06);
    }
    body.dark-mode .theme-switch .knob{
        left: 25px;
        background: #94a3b8;
    }

    .btn.view {
        background: var(--btn-bg-light);
        color: var(--btn-text);
        border: none;
    }
    .btn.edit {
        background: transparent;
        color: var(--card-text);
        border: 1px solid rgba(255,255,255,0.12);
    }
    .btn.delete {
        background: #ff6b6b;
        color: #fff;
        border: none;
    }

    @media (max-width: 767px){
        .car-title { font-size: 1.15rem; }
        .topbar { flex-direction: column; gap: 10px; align-items: flex-start; }
    }
</style>

</head>
<body>

<div class="container">

    <div class="topbar">
        <h2 class="mb-0">🚗 Stylish Car Dashboard</h2>

        <div class="toggle-switch">
            <span id="themeLabel">Light</span>
            <div id="themeToggle" class="theme-switch" role="button" aria-pressed="false" tabindex="0">
                <div class="knob"></div>
            </div>
        </div>
    </div>

    <div class="row g-4" id="carGrid">

    <%
        List<Car> carlist = (List<Car>) request.getAttribute("carlist");

        String[] colors = {
            "#ff6b6b", "#feca57", "#48dbfb",
            "#1dd1a1", "#5f27cd", "#ff9ff3",
            "#54a0ff", "#c56cf0"
        };

        String[] carImages = {
            "https://cdn.pixabay.com/photo/2016/11/29/05/08/audi-1867431_1280.jpg",
            "https://cdn.pixabay.com/photo/2014/07/31/22/50/car-407165_1280.jpg",
            "https://cdn.pixabay.com/photo/2015/01/19/13/51/car-604019_1280.jpg",
            "https://cdn.pixabay.com/photo/2013/07/12/18/20/car-153205_1280.png",
            "https://cdn.pixabay.com/photo/2018/03/16/16/08/bmw-3237952_1280.jpg",
            "https://cdn.pixabay.com/photo/2017/01/06/19/15/lamborghini-1955500_1280.jpg",
            "https://cdn.pixabay.com/photo/2017/03/27/13/56/car-2179220_1280.jpg",
            "https://cdn.pixabay.com/photo/2015/01/19/15/50/car-604019_1280.jpg"
        };

        int i = 0;

        if (carlist != null) {
            for (Car c : carlist) {
                String bg = colors[i % colors.length];
                String carImg = carImages[i % carImages.length];
                i++;
    %>

        <div class="col-md-4 col-sm-6">
            <div class="car-card" style="background: linear-gradient(135deg, <%= bg %>, rgba(255,255,255,0.06));">

                <!-- REAL CAR IMAGE ADDED HERE -->
                <img src="<%= carImg %>" class="car-img" alt="Car Image">

                <div class="car-title"><%= c.getName() %></div>
                <div class="car-info"><strong>Number:</strong> <%= c.getCarno() %></div>
                <div class="car-info"><strong>Model:</strong> <%= c.getModel() %></div>

                <div class="mt-3">
                    <button class="btn view action-btn">View</button>
                    <button class="btn edit action-btn">Edit</button>
                    <button class="btn delete action-btn">Delete</button>
                </div>

            </div>
        </div>

    <%
            }
        } else {
    %>

        <div class="col-12">
            <div class="car-card" style="background: linear-gradient(135deg, #333, rgba(255,255,255,0.03));">
                <div class="car-title">No cars found</div>
                <div class="car-info">There are currently no cars to display.</div>
            </div>
        </div>

    <%
        }
    %>

    </div>

</div>

<script>
    (function(){
        const body = document.body;
        const toggle = document.getElementById('themeToggle');
        const label = document.getElementById('themeLabel');

        const stored = localStorage.getItem('car_dashboard_theme');
        if(stored === 'dark'){
            body.classList.add('dark-mode');
            label.textContent = 'Dark';
            toggle.setAttribute('aria-pressed','true');
        }

        function switchTheme(){
            const isDark = body.classList.toggle('dark-mode');
            label.textContent = isDark ? 'Dark' : 'Light';
            toggle.setAttribute('aria-pressed', String(isDark));
            localStorage.setItem('car_dashboard_theme', isDark ? 'dark' : 'light');
        }

        toggle.addEventListener('click', switchTheme);
        toggle.addEventListener('keydown', function(e){
            if(e.key === 'Enter' || e.key === ' '){
                e.preventDefault();
                switchTheme();
            }
        });

    })();
</script>

</body>
</html>
