<%@page import="com.alpha.Car"%>
<%@page import="java.util.List"%>
<%@page import="java.util.Map"%>
<%@page import="java.util.HashMap"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Car Booking</title>

<style>
    body {
        margin: 0;
        padding: 0;
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(to bottom right, #dfe9f3, #ffffff);
    }

    .hero {
        background-image: url('https://images.unsplash.com/photo-1525609004556-c46c7d6cf023');
        background-size: cover;
        background-position: center;
        height: 250px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 38px;
        font-weight: 700;
        text-shadow: 2px 2px 10px black;
        letter-spacing: 1px;
    }

    .container {
        width: 90%;
        margin: 40px auto;
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 28px;
    }

    .car-card {
        background: #ffffff;
        border-radius: 14px;
        box-shadow: 0 5px 14px rgba(0,0,0,0.15);
        padding: 18px;
        transition: 0.35s;
        overflow: hidden;
    }

    .car-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 12px 24px rgba(0,0,0,0.30);
    }

    .car-img {
        width: 100%;
        height: 170px;
        border-radius: 12px;
        object-fit: cover;
        margin-bottom: 15px;
    }

    .car-name {
        font-size: 22px;
        font-weight: 600;
        color: #222;
    }

    .car-info {
        color: #666;
        font-size: 14px;
        margin-bottom: 6px;
    }

    /* Modern Input Styling */
    form label {
        font-size: 14px;
        font-weight: 500;
        margin-top: 10px;
        color: #333;
    }

    form input {
        width: 100%;
        padding: 10px 12px;
        margin-top: 6px;
        border-radius: 8px;
        border: 1.5px solid #ccc;
        font-size: 14px;
        transition: 0.25s;
        outline: none;
        background: #f9f9f9;
    }

    form input:focus {
        border-color: #007bff;
        background: #ffffff;
        box-shadow: 0 0 8px rgba(0,123,255,0.3);
    }

    /* Professional Button */
    button {
        width: 100%;
        margin-top: 14px;
        padding: 10px;
        background: linear-gradient(to right, #0066ff, #00c3ff);
        border: none;
        color: white;
        font-size: 16px;
        font-weight: 600;
        border-radius: 8px;
        cursor: pointer;
        transition: 0.25s;
        letter-spacing: 0.5px;
    }

    button:hover {
        background: linear-gradient(to right, #004ec9, #00a3d6);
        transform: scale(1.03);
    }

</style>
</head>

<body>

<div class="hero">Available Cars for Rent</div>

<div class="container">

<%
    List<Car> carlist = (List<Car>) request.getAttribute("carlist");

    // Car image mapping
    Map<String,String> carImageMap = new HashMap<>();

    // Kia
    carImageMap.put("Kia Seltos", "https://images.unsplash.com/photo-1542362567-069246bdbcdb?auto=format&fit=crop&w=800&q=80");

    // Audi
    carImageMap.put("Audi A4", "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=800&q=80");
    carImageMap.put("Audi Q7", "https://images.unsplash.com/photo-1603386329225-868f9ec5c06c?auto=format&fit=crop&w=800&q=80");

    // Default fallback image
    String defaultImg = "https://images.unsplash.com/photo-1493238792000-8113da705763?auto=format&fit=crop&w=800&q=80";

    for(Car c : carlist){
        String key = (c.getName() + " " + c.getModel()).trim();
        String imgUrl = carImageMap.getOrDefault(key, defaultImg);
%>

    <div class="car-card">

        <img class="car-img" src="<%= imgUrl %>" alt="Car">

        <div class="car-name"><%= c.getName() %></div>
        <div class="car-info">Car No: <%= c.getCarno() %></div>
        <div class="car-info">Model: <%= c.getModel() %></div>

        <form action="BookCar">
            <input type="hidden" name="carid" value="<%= c.getId() %>">

            <label>Customer Name:</label>
            <input type="text" name="custname" required>

            <label>Phone:</label>
            <input type="number" name="phone" required>

            <label>From Date:</label>
            <input type="date" name="fromdate" required>

            <label>To Date:</label>
            <input type="date" name="todate" required>

            <button type="submit">Book Now</button>
        </form>

    </div>

<% } %>

</div>

</body>
</html>
