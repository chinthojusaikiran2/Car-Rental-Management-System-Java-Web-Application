<%@page import="com.alpha.BookCar"%>
<%@page import="java.util.List"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Booked Cars</title>
</head>
<body>

<%
    List<BookCar> booklist = (List<BookCar>) request.getAttribute("carlist");

    if (booklist != null && !booklist.isEmpty()) {
        for (BookCar b : booklist) {
%>

<br>
<div style="border: 2px solid black; width: 250px; padding: 10px">

    <p>Car ID: <%= b.getCarid() %></p>
    <p>Customer ID: <%= b.getCustmerid() %></p>
    <p>Customer Name: <%= b.getCustname() %></p>
    <p>Phone: <%= b.getPhone() %></p>

    <form action="completebooking" method="post">
        Car ID :
        <input name="carid" value="<%= b.getCarid() %>" readonly><br><br>

        Customer ID :
        <input name="custmerid" value="<%= b.getCustmerid() %>" readonly><br><br>

        <button type="submit">Return Car</button>
    </form>

</div>

<%
        }
    } else {
%>

<h3>No booked cars found.</h3>

<%
    }
%>

</body>
</html>
