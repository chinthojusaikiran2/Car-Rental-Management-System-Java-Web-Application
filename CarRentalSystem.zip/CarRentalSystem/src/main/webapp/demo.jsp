<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<h1>pranaykoushik</h1>

<%! int a=10; %>            
<%! int b=20; %>
<h1><%= a+b %></h1>
<br>
<%! public int sub(int a,int b){
	return a-b;
}
	%>
	<h1><%= sub(50,20) %></h1>
<br>
<%! int[] arr={10,20,30,40}; %>
<% for(int a:arr){ %>
<%= a +  5%>
<% } %>

</body>
</html>
